# Đưa chat API lên Vercel (thay cho Cloudflare Worker)

Cấu trúc thư mục (giữ nguyên):
```
vercel/
├─ api/chat.js      ← hàm gọi Gemini (giữ API key)
├─ vercel.json      ← ép hàm chạy ở Washington D.C. (iad1)
└─ public/index.html
```

## Cách 1: qua GitHub (dễ nhất, không cần cài gì)
1. Tạo repo mới trên GitHub, bấm **Add file → Upload files**, kéo cả 3 mục trên vào (giữ đúng thư mục `api/`, `public/`) → **Commit**.
2. Vào https://vercel.com → **Add New → Project** → chọn repo vừa tạo → **Framework Preset: Other** → **Deploy**.

## Cách 2: dùng dòng lệnh (cần Node.js)
```
npm i -g vercel
cd vercel
vercel --prod
```

## Cài biến môi trường
Vercel → Project → **Settings → Environment Variables**, thêm (chọn Production):
- `GEMINI_API_KEY` = API key Gemini
- `ALLOWED_ORIGIN` = `https://net7-campus.page.gd` (không có dấu `/` ở cuối; khi thử trên máy thì tạm để `*`)
- `GEMINI_MODEL` = `gemini-flash-latest` (tùy chọn)
- `DEBUG` = `1` (chỉ khi cần xem lý do lỗi, xong xóa đi)

**Sau khi thêm/sửa biến phải Redeploy** (Deployments → ⋯ → Redeploy) thì mới có hiệu lực.

## Lấy URL và gắn vào trang
URL có dạng `https://ten-project.vercel.app/api/chat`. Dán vào `const CHAT_API_URL = '...';` trong file HTML.

Kiểm tra nhanh: mở URL đó trong trình duyệt → thấy `{"error":"Method not allowed"}` là hàm đang chạy.

## Nếu gặp sự cố
- Trang Vercel đòi đăng nhập / báo 401: vào Settings → **Deployment Protection**, tắt **Vercel Authentication** cho Production.
- 502 + "User location is not supported": xem `region` trong phản hồi DEBUG. Đổi `iad1` trong `vercel.json` sang vùng khác của Mỹ (vd `sfo1`, `cle1`) hoặc `sin1`, rồi Redeploy.
- 403: `ALLOWED_ORIGIN` chưa khớp domain (thử tạm `*`).
